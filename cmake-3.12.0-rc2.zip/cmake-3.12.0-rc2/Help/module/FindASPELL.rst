.. cmake-module:: ../../Modules/FindASPELL.cmake
