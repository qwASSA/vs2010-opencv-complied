.. cmake-module:: ../../Modules/FindPythonLibs.cmake
