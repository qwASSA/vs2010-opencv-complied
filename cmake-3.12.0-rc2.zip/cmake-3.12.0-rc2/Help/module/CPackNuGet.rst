.. cmake-module:: ../../Modules/CPackNuGet.cmake
